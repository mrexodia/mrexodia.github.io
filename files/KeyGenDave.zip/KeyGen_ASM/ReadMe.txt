key gen for mrexodia's crackme1. apologies if its slop, i'll blame that on the soma.
Compiled with masm32. If you would rather i make a c++ version lemme know.
Also, this code provides ZERO error checks and/or anything of the like just fyi. 
