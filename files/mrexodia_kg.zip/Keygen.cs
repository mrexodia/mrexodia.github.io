﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace MrExodia
{
	public static class Keygen
	{
		public static string GenerateSerial(string username)
		{
			byte[] userBytes = Encoding.ASCII.GetBytes(username);
			byte[] serialBytes = new byte[] {0, 0x2B, 0xE8, 0x62, 0xA7};
			for (int i = 0; i < userBytes.Length; i++)
			{
				serialBytes[1 + (i & 3)] ^= (byte)(~userBytes[i]);
			}
			serialBytes[0] = (byte)(serialBytes[1] ^ serialBytes[2] ^ serialBytes[3] ^ serialBytes[4]);
			string serial = BitConverter.ToString(serialBytes).Replace("-","");
			return serial;
		}
	}
}