int main()
{
	*(char*)0xDEADBEEF = 0;
}