#include <windows.h>
#include <stdio.h>
#include <string>
#include <dbghelp.h>
#include <cstdint>
#include <vector>
#include <type_traits>
#include <fstream>

#include <shared.h>

int gtfo(const char* text = "")
{
	printf("gtfo! (%s)\n", text);
	return -1;
}

struct Writer
{
	std::vector<uint8_t> data;

	uint32_t size()
	{
		return data.size();
	}

	uint32_t write(const void* src, size_t size)
	{
		auto offset = data.size();
		data.insert(data.end(), (uint8_t*)src, (uint8_t*)src + size);
		return offset;
	}

	uint32_t write(const std::string& str)
	{
		return write(str.data(), str.size() + 1);
	}

	uint32_t write(const char* str)
	{
		return write(str, strlen(str) + 1);
	}

	uint32_t write(const std::vector<uint8_t>& data)
	{
		return write(data.data(), data.size());
	}

	template<typename T>
	uint32_t write(const T& v)
	{
		static_assert(std::is_pod<T>::value, "only pod types for the writer");
		static_assert(!std::is_pointer<T>::value, "do not pass pointers to the writer");
		return write(&v, sizeof(v));
	}
};

DWORD align(DWORD address, DWORD size)
{
	return (address + size - 1) & ~(size - 1);
}

void rewriteBinary(const std::vector<uint8_t> importData, std::vector<uint8_t>& file, const char* password = "password")
{
	// Parse headers
	auto pdh = PIMAGE_DOS_HEADER(file.data());
	auto pnth = PIMAGE_NT_HEADERS(file.data() + pdh->e_lfanew);
	auto sections = IMAGE_FIRST_SECTION(pnth);
	auto count = pnth->FileHeader.NumberOfSections++;
	auto lastSection = sections[count - 1];
	auto sectionAlignment = pnth->OptionalHeader.SectionAlignment;
	auto fileAlignment = pnth->OptionalHeader.FileAlignment;

	// Set up new section
	auto& newSection = sections[count];
	memcpy(newSection.Name, ".packer", 7);
	newSection.VirtualAddress = align(lastSection.VirtualAddress, sectionAlignment) + align(lastSection.Misc.VirtualSize, sectionAlignment);
	newSection.Characteristics = IMAGE_SCN_CNT_CODE | IMAGE_SCN_CNT_INITIALIZED_DATA | IMAGE_SCN_MEM_WRITE | IMAGE_SCN_MEM_READ | IMAGE_SCN_MEM_EXECUTE; // 0xE0000060

	// Create section data
	Writer sectionData;

	IMAGE_THUNK_DATA thunk = {};
	thunk.u1.Ordinal = IMAGE_ORDINAL_FLAG | 1ull;
	auto firstThunkRva = newSection.VirtualAddress + sectionData.write(thunk);
	sectionData.write(uintptr_t(0)); // null thunk
	auto moduleNameRva = newSection.VirtualAddress + sectionData.write("runtime.dll");

	IMAGE_IMPORT_DESCRIPTOR desc = {};
	desc.Name = moduleNameRva;
	desc.FirstThunk = firstThunkRva;
	auto importDirectoryRva = newSection.VirtualAddress + sectionData.write(desc);
	memset(&desc, 0, sizeof(desc));
	sectionData.write(desc); // null descriptor

	// Update import directory
	auto& importDir = pnth->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
	importDir.VirtualAddress = importDirectoryRva;
	importDir.Size = 2 * sizeof(desc);

	// Zero some legacy things
	memset(&pnth->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BOUND_IMPORT], 0, sizeof(IMAGE_DATA_DIRECTORY));
	memset(&pnth->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IAT], 0, sizeof(IMAGE_DATA_DIRECTORY));

	InitStruct initStruct;
	memset(&initStruct, 0, sizeof(initStruct));
	initStruct.passwordHash = fnv1a(password, strlen(password));
	initStruct.encryptedZero = 0;
	initStruct.entryPointRva = pnth->OptionalHeader.AddressOfEntryPoint;
	auto initStructOffset = sectionData.write(initStruct);
	auto initStructRva = newSection.VirtualAddress + initStructOffset;
	sectionData.write(importData);

	// Do not encrypt the entry point
	auto encryptedOffset = offsetof(InitStruct, encryptedZero);
	initStruct.encryptedSize = sectionData.size() - initStructOffset - encryptedOffset;
	memcpy(sectionData.data.data() + initStructOffset, &initStruct, sizeof(initStruct));

	// Encrypt the data
	RC4(password, sectionData.data.data() + initStructOffset + encryptedOffset, initStruct.encryptedSize);

	// Entry point
	std::vector<uint8_t> entryPoint;

	auto entryPointRva = newSection.VirtualAddress + sectionData.size();
#ifdef _WIN64
	uint8_t shellcode[] =
	{
		0x48, 0x83, 0xEC, 0x28, // sub rsp, 0x28
		0x48, 0x89, 0x0C, 0x24, // mov [rsp], rcx
		0x48, 0x8D, 0x0D, 0x00, 0x00, 0x00, 0x00, // lea rcx, [ptr]
		0x48, 0x8D, 0x15, 0x00, 0x00, 0x00, 0x00, // lea rdx, [ptr]
		0xFF, 0x15, 0x00, 0x00, 0x00, 0x00, // call [ptr]
		0x48, 0x8B, 0x0C, 0x24, // mov rcx, [rsp]
		0x48, 0x83, 0xC4, 0x28, // add rsp, 0x28
		0xFF, 0xE0 // jmp rax
	};
	auto dispLea = initStructRva - (entryPointRva + 8) - 7;
	memcpy(shellcode + 11, &dispLea, sizeof(dispLea));
	auto dispBase = -(entryPointRva + 15) - 7;
	memcpy(shellcode + 18, &dispBase, sizeof(dispBase));
	auto dispCall = firstThunkRva - (entryPointRva + 22) - 6;
	memcpy(shellcode + 24, &dispCall, sizeof(dispCall));
	entryPoint.insert(entryPoint.end(), std::begin(shellcode), std::end(shellcode));
#else
#error not yet supported!
#endif // _WIN64

	sectionData.write(entryPoint);

	pnth->OptionalHeader.AddressOfEntryPoint = entryPointRva;

	// Finalize new section
	newSection.Misc.VirtualSize = sectionData.size();
	sectionData.data.resize(align(sectionData.size(), fileAlignment));
	newSection.SizeOfRawData = sectionData.size();
	newSection.PointerToRawData = file.size();
	pnth->OptionalHeader.SizeOfImage += align(newSection.Misc.VirtualSize, sectionAlignment);

	// Append the data
	file.insert(file.end(), sectionData.data.begin(), sectionData.data.end());
}

int main(int argc, char* argv[])
{
	//LEAKY AND UNSAFE!
	if (argc < 2)
		return gtfo("argc");

	bool fakeEverything = argc > 2;

	char sysdir[MAX_PATH];
	if (!GetSystemDirectoryA(sysdir, MAX_PATH))
		return gtfo("GetSystemDirectory");

	char exedir[MAX_PATH];
	GetModuleFileNameA(GetModuleHandle(0), exedir, MAX_PATH);
	*strrchr(exedir, '\\') = '\0';

	//read the file
	auto hFile = CreateFileA(argv[1], GENERIC_READ, FILE_SHARE_READ, nullptr, OPEN_EXISTING, 0, nullptr);
	if (hFile == INVALID_HANDLE_VALUE)
		return gtfo("CreateFile");

	//map the file
	auto hMappedFile = CreateFileMappingA(hFile, nullptr, PAGE_READONLY | SEC_IMAGE, 0, 0, nullptr); //notice SEC_IMAGE
	if (!hMappedFile)
		return gtfo("CreateFileMappingA");

	//map the sections appropriately
	auto fileMap = MapViewOfFile(hMappedFile, FILE_MAP_READ, 0, 0, 0);
	if (!fileMap)
		return gtfo("MapViewOfFile");

	auto pidh = PIMAGE_DOS_HEADER(fileMap);
	if (pidh->e_magic != IMAGE_DOS_SIGNATURE)
		return gtfo("IMAGE_DOS_SIGNATURE");

	auto pnth = PIMAGE_NT_HEADERS(ULONG_PTR(fileMap) + pidh->e_lfanew);
	if (pnth->Signature != IMAGE_NT_SIGNATURE)
		return gtfo("IMAGE_NT_SIGNATURE");

#ifdef _WIN64
	if (pnth->FileHeader.Machine != IMAGE_FILE_MACHINE_AMD64)
		return gtfo("IMAGE_FILE_MACHINE_AMD64");
#else
	if (pnth->FileHeader.Machine != IMAGE_FILE_MACHINE_I386)
		return gtfo("IMAGE_FILE_MACHINE_I386");
#endif //_WIN64

	if (pnth->OptionalHeader.Magic != IMAGE_NT_OPTIONAL_HDR_MAGIC)
		return gtfo("IMAGE_NT_OPTIONAL_HDR_MAGIC");

	auto importDir = pnth->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
	puts("Import Directory");
	printf(" RVA: %08X\n", importDir.VirtualAddress);
	printf("Size: %08X\n\n", importDir.Size);

	if (!importDir.VirtualAddress || !importDir.Size)
		return gtfo("No Import directory!");

	Writer importData;

	auto importDescriptor = PIMAGE_IMPORT_DESCRIPTOR(ULONG_PTR(fileMap) + importDir.VirtualAddress);
	if (!IsBadReadPtr((char*)fileMap + importDir.VirtualAddress, 0x1000))
	{
		for (; importDescriptor->FirstThunk; importDescriptor++)
		{
			printf("OriginalFirstThunk: %08X\n", importDescriptor->OriginalFirstThunk);
			printf("     TimeDateStamp: %08X\n", importDescriptor->TimeDateStamp);
			printf("    ForwarderChain: %08X\n", importDescriptor->ForwarderChain);
			const char* modname = nullptr;
			if (!IsBadReadPtr((char*)fileMap + importDescriptor->Name, 0x1000))
				modname = (char*)fileMap + importDescriptor->Name;
			if (modname)
				printf("              Name: %08X \"%s\"\n", importDescriptor->Name, modname);
			else
				printf("              Name: %08X INVALID\n", importDescriptor->Name);
			printf("              Name: %08X\n", importDescriptor->Name);
			printf("        FirstThunk: %08X\n", importDescriptor->FirstThunk);

			if (!modname)
			{
				puts("    SKIPPING!");
				continue;
			}

			importData.write(ImportMagic::Module);
			importData.write(importDescriptor->FirstThunk);
			importData.write(modname);

			auto thunkData = PIMAGE_THUNK_DATA(ULONG_PTR(fileMap) + importDescriptor->FirstThunk);
			for (; thunkData->u1.AddressOfData; thunkData++)
			{
				auto rva = ULONG_PTR(thunkData) - ULONG_PTR(fileMap);

				auto data = thunkData->u1.AddressOfData;
				if (data & IMAGE_ORDINAL_FLAG)
				{
					auto ordinal = data & ~IMAGE_ORDINAL_FLAG;
					printf("              Ordinal: %p\n", (void*)ordinal);
					char ordname[256];
					sprintf_s(ordname, "%zu", ordinal);
					importData.write(ImportMagic::OrdinalImport);
					importData.write(ordinal);
				}
				else
				{
					auto importByName = PIMAGE_IMPORT_BY_NAME(ULONG_PTR(fileMap) + data);
					if (!IsBadReadPtr(importByName, 0x1000))
					{
						auto impname = (const char*)importByName->Name;
						printf("             Function: %p \"%s\"\n", (void*)data, impname);
						importData.write(ImportMagic::NamedImport);
						importData.write(impname);
					}
					else
						printf("             Function: %p INVALID\n", (void*)data);
				}
			}

			puts("");
		}
	}
	else
		puts("INVALID IMPORT DESCRIPTOR");

	for (int i = 0; i < 16; i++)
		importData.write(ImportMagic::End);

	{
		std::ofstream ofs("iat.bin", std::ios_base::binary);
		if (!ofs)
			return gtfo("iat.bin");
		ofs.write((const char*)importData.data.data(), importData.data.size());
	}

	std::vector<uint8_t> data(GetFileSize(hFile, nullptr));
	DWORD read = 0;
	if (!ReadFile(hFile, data.data(), data.size(), &read, nullptr))
		return gtfo("read file");

	rewriteBinary(importData.data, data);
	{
		std::ofstream ofs("packed.exe", std::ios_base::binary);
		if (!ofs)
			return gtfo("packed.exe");
		ofs.write((const char*)data.data(), data.size());
	}

	return 0;
}
