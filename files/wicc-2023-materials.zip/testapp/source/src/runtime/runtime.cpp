#include <Windows.h>
#include <shared.h>
#include <wincred.h>
#include <string>

#pragma comment(lib, "Credui.lib")

class Reader
{
	const uint8_t* data = nullptr;

public:
	explicit Reader(const uint8_t* data)
		: data(data)
	{
	}

	template<typename T>
	T read()
	{
		T result;
		memcpy(&result, data, sizeof(T));
		data += sizeof(T);
		return result;
	}

	const char* read_str()
	{
		auto result = (const char*)data;
		data += strlen(result) + 1;
		return result;
	}
};

static void promptPassword(InitStruct& init)
{
	DWORD credFlags = CREDUI_FLAGS_GENERIC_CREDENTIALS | CREDUI_FLAGS_DO_NOT_PERSIST | CREDUI_FLAGS_KEEP_USERNAME;
	while (true)
	{
		CREDUI_INFO cui;
		TCHAR credLoc[CREDUI_MAX_USERNAME_LENGTH] = "";
		TCHAR pszName[CREDUI_MAX_USERNAME_LENGTH] = "";
		DWORD cb = _countof(pszName);
		GetUserNameA(pszName, &cb);
		TCHAR pszPwd[CREDUI_MAX_PASSWORD_LENGTH] = "";

		cui.cbSize = sizeof(CREDUI_INFO);
		cui.hwndParent = NULL;
		//  Ensure that MessageText and CaptionText identify
		//  what credentials to use and which application requires them.
		cui.pszMessageText = TEXT("Enter the password to unlock this application");
		cui.pszCaptionText = TEXT("Protected application");
		cui.hbmBanner = NULL;

		//  Create the UI asking for the credentials.
		auto result = CredUIPromptForCredentialsA(
			&cui,// CREDUI_INFO structure
			credLoc, // Target for credentials
			NULL, // Reserved
			0, // Reason
			pszName, // User name
			CREDUI_MAX_USERNAME_LENGTH, // Max number for user name
			pszPwd, //  Password
			CREDUI_MAX_PASSWORD_LENGTH, // Max number for password
			NULL, // State of save check box
			credFlags // Flags
		);

		if (result == ERROR_CANCELLED)
		{
			ExitProcess(-1);
		}
		else if (result == NO_ERROR)
		{
			if (fnv1a(pszPwd, strlen(pszPwd)) == init.passwordHash)
			{
				RC4(pszPwd, &init.encryptedZero, init.encryptedSize);
				if (init.encryptedZero != 0)
				{
					MessageBoxA(0, "Error decrypting data (hash collision?)", "Fatal error", MB_SYSTEMMODAL | MB_ICONERROR);
					ExitProcess(-2);
				}
				return;
			}

			// Try again with an invalid password message
			credFlags |= CREDUI_FLAGS_INCORRECT_PASSWORD;
			*pszPwd = '\0';
		}
		else
		{
			MessageBoxA(0, "Something went wrong...", "CredUIPromptForCredentialsA", MB_SYSTEMMODAL | MB_ICONERROR);
			ExitProcess(-3);
		}
	}
}

#pragma comment(linker, "/EXPORT:initialize,@1,NONAME")

extern "C" __declspec(dllexport) uintptr_t initialize(InitStruct & init, uintptr_t imageBase)
{
	// prompt password and decrypt the InitStruct
	promptPassword(init);

	// restore imports
	Reader imports(init.importData);
	FARPROC* iatPointer = nullptr;
	HMODULE iatModule = nullptr;
	while (true)
	{
		auto magic = imports.read<ImportMagic>();
		if (magic == ImportMagic::Module)
		{
			auto iatRva = imports.read<uint32_t>();
			iatPointer = (FARPROC*)(imageBase + iatRva);
			auto name = imports.read_str();
			iatModule = LoadLibraryA(name);
		}
		else if (iatPointer && iatModule && magic == ImportMagic::NamedImport)
		{
			auto name = imports.read_str();
			DWORD old = 0;
			VirtualProtect(iatPointer, sizeof(FARPROC), PAGE_READWRITE, &old);
			*iatPointer = GetProcAddress(iatModule, name);
			VirtualProtect(iatPointer, sizeof(FARPROC), old, &old);
			iatPointer++;
		}
		else if (iatPointer && iatModule && magic == ImportMagic::OrdinalImport)
		{
			auto ordinal = imports.read<uintptr_t>();
			DWORD old = 0;
			VirtualProtect(iatPointer, sizeof(FARPROC), PAGE_READWRITE, &old);
			*iatPointer = GetProcAddress(iatModule, (LPCSTR)ordinal);
			VirtualProtect(iatPointer, sizeof(FARPROC), old, &old);
			iatPointer++;
		}
		else if (magic == ImportMagic::End)
		{
			break;
		}
		else
		{
			__debugbreak();
		}
	}

	return imageBase + init.entryPointRva;
}