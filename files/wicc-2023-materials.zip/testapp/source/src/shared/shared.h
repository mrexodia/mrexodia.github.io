#pragma once

#include <cstdint>

#pragma pack(push, 1)
struct InitStruct
{
    uint32_t passwordHash;
    uint32_t encryptedSize;
    uint32_t encryptedZero; // should be zero when decrypted
    uint32_t entryPointRva;
    uint8_t importData[0];
};
#pragma pack(pop)

enum class ImportMagic : uint8_t
{
    Module,
    NamedImport,
    OrdinalImport,
    End = 0x90,
};

uint32_t fnv1a(const void* data, size_t numBytes);
void RC4(const char* key, void* buffer, size_t size);